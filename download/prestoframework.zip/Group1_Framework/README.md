# Group1_Framework
FEWD2 GROUP1 Framework
